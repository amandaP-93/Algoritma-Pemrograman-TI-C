# Penambahan(a, b)
#mengembalikan hasil penjumlahan dua bilangan

def tambah(a, b)
    return a+b
def kurang(a, b)
    return a-b
def kali(a, b)
    return a*b
def bagi(a, b)
    if b==0:
        hasil="Pembagian tidak dapat dilakukan karena pembagi bernilai 0"
    else:
        hasil=a/b
def mod(a ,b):
    return a%b
print(mod(a, b))
def fibonacci(n):
    if n <= 1:
        return n
    else:
        



